﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TapangGraphicsApp
{
    public partial class Form1 : Form
    {
        //For StaturBar
       // protected StatusBar mainStatusBar = new StatusBar();
       // protected StatusBarPanel statusPanel = new StatusBarPanel();
       // protected StatusBarPanel datetimePanel = new StatusBarPanel();
        //---------------------

        int x1, y1, x2, y2;     
        int myPenWidth;
        Item currItem;
        Pen myPen = new Pen(System.Drawing.Color.Black, 3.0F);
        bool draw;
        bool withPt1;
        bool withPt2;
        bool emptyCanvas;
        bool workSaved;
        bool fromPolyLine;

       

        public Form1()
        {
            InitializeComponent();

            //For StatusBar
            /*
            statusPanel.BorderStyle = StatusBarPanelBorderStyle.Sunken;
            statusPanel.Text = "Application started. No action yet.";
            statusPanel.ToolTipText = "Last Activity";
            statusPanel.AutoSize = StatusBarPanelAutoSize.Spring;
            mainStatusBar.Panels.Add(statusPanel);
            datetimePanel.BorderStyle = StatusBarPanelBorderStyle.Raised;
            datetimePanel.ToolTipText = "DateTime: " + System.DateTime.Today.ToString();
            datetimePanel.Text = System.DateTime.Today.ToLongDateString();
            datetimePanel.AutoSize = StatusBarPanelAutoSize.Contents;
            mainStatusBar.Panels.Add(datetimePanel);
            mainStatusBar.ShowPanels = true;
            this.Controls.Add(mainStatusBar);
             */
            //--------------------------


            //-----------------------------
            currItem = Item.None;
            myPenWidth = 3;
            draw = false;
            withPt1 = false;
            withPt2 = false;
            emptyCanvas = true;
            workSaved = false;
            fromPolyLine = false;
            

        }

        public enum Item
        {
            None, Line, Rectangle, Ellipse, Brush, Text, Pencil, Eraser, Polyline
        }

        //GridLine for the pictureBox
        private void gridLinesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (emptyCanvas)
            {
                if (gridLinesToolStripMenuItem.Checked == false)
                {
                    pictureBox1.BackgroundImage = Image.FromFile("C:/Users/Keen/Desktop/ForCS135/JonelTapangGraphicsApp/TapangGraphicsApp/Resources/griid.png");
                    gridLinesToolStripMenuItem.Checked = true;
                }
                else if (gridLinesToolStripMenuItem.Checked == true)
                {
                    pictureBox1.BackgroundImage = null;
                    gridLinesToolStripMenuItem.Checked = false; ;
                }
            }
            else
            {
                MessageBox.Show("Cannot change Gridline view while canvas is not empty", "Warning!",
                MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ssDate.Text = System.DateTime.Today.ToLongDateString();

            if (currItem == Item.None)
            {
                ssInstruction.Text = "Instruction: (None)";
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (currItem != Item.None)
            {
                draw = true;

                if (fromPolyLine && currItem!= Item.Polyline)
                {
                    withPt1 = false;
                    withPt2 = false;
                    fromPolyLine = false;
                }

                if (currItem != Item.Text)
                {
                    if (!withPt1 && !withPt2)
                    {
                        x1 = e.X;
                        y1 = e.Y;
                        withPt1 = true;
                    }
                    else if (withPt1 && !withPt2)
                    {
                        x2 = e.X;
                        y2 = e.Y;
                        withPt2 = true;
                    }
                }

                switch (currItem)
                { 
                    case Item.Line:
                        if (withPt1)
                            ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 +"). Click an End point of the Line";
                        break;

                    case Item.Rectangle:
                            ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Rectangle";
                        break;

                    case Item.Ellipse:
                        ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Ellipse";
                        break;
                }
                



                //Inserting Text
                if (currItem == Item.Text)
                {
                    Graphics G = pictureBox1.CreateGraphics();
                    myPen.Width = myPenWidth;

                    string fontFam = textFont.Text;
                    int fontSize = Convert.ToInt16(textFontSize.Text);
                    Brush myBrush = new SolidBrush(myPen.Color);

                    if (textFontStyle.Text == "Regular")
                    {

                        Font myFont = new System.Drawing.Font(fontFam, fontSize, FontStyle.Regular);
                        G.DrawString(textContainer.Text, myFont, myBrush, e.X, e.Y);
                    }
                    else if (textFontStyle.Text == "Italic")
                    {

                        Font myFont = new System.Drawing.Font(fontFam, fontSize, FontStyle.Italic);
                        G.DrawString(textContainer.Text, myFont, myBrush, e.X, e.Y);
                    }
                    else if (textFontStyle.Text == "Underline")
                    {

                        Font myFont = new System.Drawing.Font(fontFam, fontSize, FontStyle.Underline);
                        G.DrawString(textContainer.Text, myFont, myBrush, e.X, e.Y);
                    }
                    else if (textFontStyle.Text == "Bold")
                    {

                        Font myFont = new System.Drawing.Font(fontFam, fontSize, FontStyle.Bold);
                        G.DrawString(textContainer.Text, myFont, myBrush, e.X, e.Y);
                    }
                    emptyCanvas = false;
                }
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if ((withPt1 && withPt2) && (draw && currItem != Item.None) )
            {
                draw = false;

                Graphics G = pictureBox1.CreateGraphics();
                myPen.Width = myPenWidth;
                Rectangle myRectangle = new Rectangle(x1, y1, e.X - x1, e.Y - y1);

                switch (currItem)
                { 
                    case Item.Line:
                        G.DrawLine(myPen, x1, y1, x2, y2);
                        ssInstruction.Text = "Intruction: Line drawn from (" + x1 + ", " + y1 + ") to (" + x2 + ", " + y2 + ")";
                        withPt1 = false;
                        withPt2 = false;
                        emptyCanvas = false;
                        break;
                    
                    case Item.Rectangle:
                        G.DrawRectangle(myPen, myRectangle);
                        ssInstruction.Text = "Intruction: Rectangle drawn from (" + x1 + ", " + y1 + ") to (" + x2 + ", " + y2 + ")";
                        withPt1 = false;
                        withPt2 = false;
                        emptyCanvas = false;
                        break;

                    case Item.Ellipse:
                        G.DrawEllipse(myPen, myRectangle);
                        ssInstruction.Text = "Intruction: Ellipse drawn from (" + x1 + ", " + y1 + ") to (" + x2 + ", " + y2 + ")";
                        withPt1 = false;
                        withPt2 = false;
                        emptyCanvas = false;
                        break;

                    case Item.Polyline:
                        x2 = e.X;
                        y2 = e.Y;
                        G.DrawLine(myPen, x1, y1, x2, y2);
                        ssInstruction.Text = "Intruction: Line drawn from (" + x1 + ", " + y1 + ") to (" + x2 + ", " + y2 + ")";
                        x1 = x2;
                        y1 = y2;
                        fromPolyLine = true;
                        emptyCanvas = false;
                        break;
                }   
            }           
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            ssCursorLoc.Text = "Cursor Location: " + e.X + ", " + e.Y + " px";


            Graphics G = pictureBox1.CreateGraphics();

            if (draw)
            {
                switch (currItem)
                {
                    case Item.Brush:
                        G.FillEllipse(new SolidBrush(myPen.Color), e.X - x1 + x1, e.Y - y1 + y1, myPenWidth + 10, myPenWidth + 10);
                        emptyCanvas = false;
                        break;
                    case Item.Pencil:
                        G.FillEllipse(new SolidBrush(myPen.Color), e.X - x1 + x1, e.Y - y1 + y1, 3, 3);
                        emptyCanvas = false;
                        break;
                    case Item.Eraser:
                        G.FillEllipse(new SolidBrush(pictureBox1.BackColor), e.X - x1 + x1, e.Y - y1 + y1, myPenWidth + 20, myPenWidth + 20);
                        emptyCanvas = false;
                        break;
                }
            }  
        }

        private void drawLine_Click(object sender, EventArgs e)
        {
            textOptionPanel.Visible = false;
            currItem = Item.Line;

            if (!withPt1)
            {
                ssInstruction.Text = "Intruction: Click starting point of the Line";
            }
            else if (withPt1)
            {
                ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Line";
            }

            drawLine.Enabled = false;
            drawRec.Enabled = true;
            drawEllipse.Enabled = true;
            eraser.Enabled = true;
            insertText.Enabled = true;
            Drawpoly.Enabled = true;

            drawRec.Checked = false;
            drawEllipse.Checked = false;
            eraser.Checked = false;
            insertText.Checked = false;
            Drawpoly.Checked = false;
        }

        private void drawRec_Click(object sender, EventArgs e)
        {
            textOptionPanel.Visible = false;
            currItem = Item.Rectangle;

            if (!withPt1)
            {
                ssInstruction.Text = "Intruction: Click starting point of the Rectangle";
            }
            else if (withPt1)
            {
                ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Rectangle";
            }

            drawLine.Enabled = true;
            drawRec.Enabled = false; ;
            drawEllipse.Enabled = true;
            eraser.Enabled = true;
            insertText.Enabled = true;
            Drawpoly.Enabled = true;

            drawLine.Checked = false;
            drawEllipse.Checked = false;
            eraser.Checked = false;
            insertText.Checked = false;
            Drawpoly.Checked = false;

        }

        private void drawEllipse_Click(object sender, EventArgs e)
        {
            textOptionPanel.Visible = false;
            currItem = Item.Ellipse;
            if (!withPt1)
            {
                ssInstruction.Text = "Intruction: Click starting point of the Ellipse";
            }
            else if (withPt1)
            {
                ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Ellipse";
            }

            drawLine.Enabled = true;
            drawRec.Enabled = true;
            drawEllipse.Enabled = false;
            eraser.Enabled = true;
            insertText.Enabled = true;
            Drawpoly.Enabled = true;

            drawLine.Checked = false;
            drawRec.Checked = false;
            eraser.Checked = false;
            insertText.Checked = false;
            Drawpoly.Checked = false;
        }

        private void eraser_Click(object sender, EventArgs e)
        {
            textOptionPanel.Visible = false;
            currItem = Item.Eraser;

            ssInstruction.Text = "Instruction: Click and Drag to the Section you want to Erase";

            drawLine.Enabled = true;
            drawRec.Enabled = true;
            drawEllipse.Enabled = true;
            eraser.Enabled = false;
            insertText.Enabled = true;
            Drawpoly.Enabled = true;

            drawLine.Checked = false;
            drawRec.Checked = false;
            drawEllipse.Checked = false;
            insertText.Checked = false;
            Drawpoly.Checked = false;
        }

        private void insertText_Click(object sender, EventArgs e)
        {
            textContainer.Text = "";
            textOptionPanel.Visible = true;
            currItem = Item.Text;

            ssInstruction.Text = "Instruction: Click Starting Point of the Text";


            drawLine.Enabled = true;
            drawRec.Enabled = true;
            drawEllipse.Enabled = true;
            eraser.Enabled = true;
            insertText.Enabled = false;
            Drawpoly.Enabled = true;

            drawLine.Checked = false;
            drawRec.Checked = false;
            drawEllipse.Checked = false;
            eraser.Checked = false;
            Drawpoly.Checked = false;
        }

        private void Drawpoly_Click(object sender, EventArgs e)
        {
            textOptionPanel.Visible = false;
            currItem = Item.Polyline;

            if (!withPt1)
            {
                ssInstruction.Text = "Instruction: Click Starting Point of the Line";
            }
            else if (withPt1)
            {
                ssInstruction.Text = "Intruction: Clicked at (" + x1 + ", " + y1 + "). Click an End point of the Line";
            }
            drawLine.Enabled = true;
            drawRec.Enabled = true;
            drawEllipse.Enabled = true;
            eraser.Enabled = true;
            insertText.Enabled = true;
            Drawpoly.Enabled = false;

            drawLine.Checked = false;
            drawRec.Checked = false;
            drawEllipse.Checked = false;
            eraser.Checked = false;
            insertText.Checked = false;
        }      

        
        private void changeColor(object sender, EventArgs e)
        {
            if (sender == blackToolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.Black;
                ColorHolderBox.BackColor = Color.Black;

            }
            else if (sender == whiteToolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.White;
                ColorHolderBox.BackColor = Color.White;
         
            }
            else if (sender == redToolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.Red;
                ColorHolderBox.BackColor = Color.Red;
            }
            else if (sender == yellowtoolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.Yellow;
                ColorHolderBox.BackColor = Color.Yellow;

            }
            else if (sender == greentoolStripMenuItem) 
            {
                myPen.Color = System.Drawing.Color.Green;
                ColorHolderBox.BackColor = Color.Green;
            }
            else if (sender == bluetoolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.Blue;
                ColorHolderBox.BackColor = Color.Blue;
            }
            else if (sender == brownToolStripMenuItem)
            {
                myPen.Color = System.Drawing.Color.Brown;
                ColorHolderBox.BackColor = Color.Brown;
            }
        }
         

        private void penWidth(object sender, EventArgs e)
        {
            if (sender == level0)
            {
                myPenWidth = 1;

                level1.Checked = false;
                level2.Checked = false;
                level3.Checked = false;
            }
            else if (sender == level1)
            {
                myPenWidth = 2;

                level0.Checked = false;
                level2.Checked = false;
                level3.Checked = false;
            }
            else if (sender == level2)
            {
                myPenWidth = 3;

                level0.Checked = false;
                level1.Checked = false;
                level3.Checked = false;
            }
            else if (sender == level3)
            {
                myPenWidth = 4;

                level0.Checked = false;
                level1.Checked = false;
                level2.Checked = false;
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;

            dashLine.Checked = false;
            dashDot.Checked = false;
            dashLineDot.Checked = false;
            dashLineDotDot.Checked = false;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            
            solidLine.Checked = false;
            dashDot.Checked = false;
            dashLineDot.Checked = false;
            dashLineDotDot.Checked = false;
        }

        private void dashDotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

            solidLine.Checked = false;
            dashLine.Checked = false;
            dashLineDot.Checked = false;
            dashLineDotDot.Checked = false;
        }

        private void dashLineDotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;

            solidLine.Checked = false;
            dashLine.Checked = false;
            dashDot.Checked = false;
            dashLineDotDot.Checked = false;
        }

        private void dashLineDotDotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;

            solidLine.Checked = false;
            dashLine.Checked = false;
            dashDot.Checked = false;
            dashLineDot.Checked = false;
        }

        private void resetCanvas_Click(object sender, EventArgs e)
        {
            DialogResult MessBox = MessageBox.Show("Are you sure to Reset Canvas?", "Warning!",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (MessBox == System.Windows.Forms.DialogResult.Yes)
            {
                if (gridLinesToolStripMenuItem.Checked == true)
                {
                    pictureBox1.BackgroundImage = Image.FromFile("C:/Users/Keen/Desktop/ForCS135/JonelTapangGraphicsApp/TapangGraphicsApp/Resources/griid.png");
                }
                else if (gridLinesToolStripMenuItem.Checked == false)
                {
                    pictureBox1.BackgroundImage = Image.FromFile("C:/Users/Keen/Desktop/ForCS135/JonelTapangGraphicsApp/TapangGraphicsApp/Resources/whitebkg.png");
                }
                emptyCanvas = true;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!workSaved)
            {
                DialogResult MessBox = MessageBox.Show("Are you sure you want to close application without saving current work?", "Warning!",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                if (MessBox == System.Windows.Forms.DialogResult.Yes)
                {
                    if (System.Windows.Forms.Application.MessageLoop)
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                }
            }
            else if (workSaved)
            {
                DialogResult MessBox = MessageBox.Show("Closing Application", "Thank you!",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                System.Windows.Forms.Application.Exit();
            }           
        }

    }
}
