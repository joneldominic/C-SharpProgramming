﻿namespace TapangGraphicsApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.resetCanvas = new System.Windows.Forms.ToolStripMenuItem();
            this.penWidthbox = new System.Windows.Forms.ToolStripMenuItem();
            this.gridLinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.customizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.colorBox = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ColorHolderBox = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.redToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yellowtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greentoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bluetoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.whiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.level0 = new System.Windows.Forms.ToolStripMenuItem();
            this.level1 = new System.Windows.Forms.ToolStripMenuItem();
            this.level2 = new System.Windows.Forms.ToolStripMenuItem();
            this.level3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.solidLine = new System.Windows.Forms.ToolStripMenuItem();
            this.dashLine = new System.Windows.Forms.ToolStripMenuItem();
            this.dashDot = new System.Windows.Forms.ToolStripMenuItem();
            this.dashLineDot = new System.Windows.Forms.ToolStripMenuItem();
            this.dashLineDotDot = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.drawLine = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.Drawpoly = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.drawRec = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.drawEllipse = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.eraser = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.insertText = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.textFontStyle = new System.Windows.Forms.ComboBox();
            this.textOptionPanel = new System.Windows.Forms.Panel();
            this.textContainer = new System.Windows.Forms.TextBox();
            this.textFontSize = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textFont = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ssInstruction = new System.Windows.Forms.ToolStripStatusLabel();
            this.ssCursorLoc = new System.Windows.Forms.ToolStripStatusLabel();
            this.ssDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.colorBox.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.textOptionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textFontSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.editToolStripMenuItem1,
            this.penWidthbox,
            this.toolsToolStripMenuItem1,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1305, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem1,
            this.openToolStripMenuItem1,
            this.toolStripSeparator,
            this.saveToolStripMenuItem1,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "&File";
            // 
            // newToolStripMenuItem1
            // 
            this.newToolStripMenuItem1.Enabled = false;
            this.newToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem1.Image")));
            this.newToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripMenuItem1.Name = "newToolStripMenuItem1";
            this.newToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.newToolStripMenuItem1.Text = "&New";
            // 
            // openToolStripMenuItem1
            // 
            this.openToolStripMenuItem1.Enabled = false;
            this.openToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem1.Image")));
            this.openToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripMenuItem1.Name = "openToolStripMenuItem1";
            this.openToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.openToolStripMenuItem1.Text = "&Open";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(143, 6);
            // 
            // saveToolStripMenuItem1
            // 
            this.saveToolStripMenuItem1.Enabled = false;
            this.saveToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem1.Image")));
            this.saveToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripMenuItem1.Name = "saveToolStripMenuItem1";
            this.saveToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.saveToolStripMenuItem1.Text = "&Save";
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Enabled = false;
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.saveAsToolStripMenuItem.Text = "Save &As";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(143, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Enabled = false;
            this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
            this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.printToolStripMenuItem.Text = "&Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Enabled = false;
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(143, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem1
            // 
            this.editToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator3,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem1,
            this.pasteToolStripMenuItem1,
            this.toolStripSeparator4,
            this.resetCanvas});
            this.editToolStripMenuItem1.Name = "editToolStripMenuItem1";
            this.editToolStripMenuItem1.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem1.Text = "&Edit";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Enabled = false;
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.undoToolStripMenuItem.Text = "&Undo";
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Enabled = false;
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.redoToolStripMenuItem.Text = "&Redo";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(141, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Enabled = false;
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.cutToolStripMenuItem.Text = "Cu&t";
            // 
            // copyToolStripMenuItem1
            // 
            this.copyToolStripMenuItem1.Enabled = false;
            this.copyToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem1.Image")));
            this.copyToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripMenuItem1.Name = "copyToolStripMenuItem1";
            this.copyToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.copyToolStripMenuItem1.Text = "&Copy";
            // 
            // pasteToolStripMenuItem1
            // 
            this.pasteToolStripMenuItem1.Enabled = false;
            this.pasteToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem1.Image")));
            this.pasteToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripMenuItem1.Name = "pasteToolStripMenuItem1";
            this.pasteToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.pasteToolStripMenuItem1.Text = "&Paste";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // resetCanvas
            // 
            this.resetCanvas.Name = "resetCanvas";
            this.resetCanvas.Size = new System.Drawing.Size(144, 22);
            this.resetCanvas.Text = "Reset Canvas";
            this.resetCanvas.Click += new System.EventHandler(this.resetCanvas_Click);
            // 
            // penWidthbox
            // 
            this.penWidthbox.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gridLinesToolStripMenuItem});
            this.penWidthbox.Name = "penWidthbox";
            this.penWidthbox.Size = new System.Drawing.Size(44, 20);
            this.penWidthbox.Text = "View";
            // 
            // gridLinesToolStripMenuItem
            // 
            this.gridLinesToolStripMenuItem.Checked = true;
            this.gridLinesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.gridLinesToolStripMenuItem.Name = "gridLinesToolStripMenuItem";
            this.gridLinesToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.gridLinesToolStripMenuItem.Text = "Grid Lines";
            this.gridLinesToolStripMenuItem.Click += new System.EventHandler(this.gridLinesToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customizeToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem1.Text = "&Tools";
            // 
            // customizeToolStripMenuItem
            // 
            this.customizeToolStripMenuItem.Enabled = false;
            this.customizeToolStripMenuItem.Name = "customizeToolStripMenuItem";
            this.customizeToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.customizeToolStripMenuItem.Text = "&Customize";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Enabled = false;
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Enabled = false;
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.contentsToolStripMenuItem.Text = "&Contents";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Enabled = false;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.indexToolStripMenuItem.Text = "&Index";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Enabled = false;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.searchToolStripMenuItem.Text = "&Search";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(119, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Enabled = false;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStrip1.Size = new System.Drawing.Size(1305, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "`";
            // 
            // colorBox
            // 
            this.colorBox.BackColor = System.Drawing.Color.White;
            this.colorBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.colorBox.Dock = System.Windows.Forms.DockStyle.None;
            this.colorBox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator8,
            this.ColorHolderBox,
            this.toolStripSeparator9,
            this.toolStripButton1});
            this.colorBox.Location = new System.Drawing.Point(0, 24);
            this.colorBox.Name = "colorBox";
            this.colorBox.Size = new System.Drawing.Size(76, 25);
            this.colorBox.TabIndex = 4;
            this.colorBox.Text = "toolStrip2";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // ColorHolderBox
            // 
            this.ColorHolderBox.BackColor = System.Drawing.Color.Black;
            this.ColorHolderBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ColorHolderBox.Enabled = false;
            this.ColorHolderBox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorHolderBox.Name = "ColorHolderBox";
            this.ColorHolderBox.Size = new System.Drawing.Size(23, 22);
            this.ColorHolderBox.Text = "toolStripButton2";
            this.ColorHolderBox.ToolTipText = "Current Color";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.redToolStripMenuItem,
            this.yellowtoolStripMenuItem,
            this.greentoolStripMenuItem,
            this.bluetoolStripMenuItem,
            this.brownToolStripMenuItem,
            this.blackToolStripMenuItem,
            this.whiteToolStripMenuItem});
            this.toolStripButton1.Image = global::TapangGraphicsApp.Properties.Resources.colorwheel;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Color Options";
            // 
            // redToolStripMenuItem
            // 
            this.redToolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.red;
            this.redToolStripMenuItem.Name = "redToolStripMenuItem";
            this.redToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.redToolStripMenuItem.Text = "Red";
            this.redToolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // yellowtoolStripMenuItem
            // 
            this.yellowtoolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.black;
            this.yellowtoolStripMenuItem.Name = "yellowtoolStripMenuItem";
            this.yellowtoolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.yellowtoolStripMenuItem.Text = "Yellow";
            this.yellowtoolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // greentoolStripMenuItem
            // 
            this.greentoolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.ggg;
            this.greentoolStripMenuItem.Name = "greentoolStripMenuItem";
            this.greentoolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.greentoolStripMenuItem.Text = "Green";
            this.greentoolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // bluetoolStripMenuItem
            // 
            this.bluetoolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.blue;
            this.bluetoolStripMenuItem.Name = "bluetoolStripMenuItem";
            this.bluetoolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.bluetoolStripMenuItem.Text = "Blue";
            this.bluetoolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // brownToolStripMenuItem
            // 
            this.brownToolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.brown;
            this.brownToolStripMenuItem.Name = "brownToolStripMenuItem";
            this.brownToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.brownToolStripMenuItem.Text = "Brown";
            this.brownToolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // blackToolStripMenuItem
            // 
            this.blackToolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.blackblack;
            this.blackToolStripMenuItem.Name = "blackToolStripMenuItem";
            this.blackToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.blackToolStripMenuItem.Text = "Black";
            this.blackToolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // whiteToolStripMenuItem
            // 
            this.whiteToolStripMenuItem.Image = global::TapangGraphicsApp.Properties.Resources.white;
            this.whiteToolStripMenuItem.Name = "whiteToolStripMenuItem";
            this.whiteToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.whiteToolStripMenuItem.Text = "White";
            this.whiteToolStripMenuItem.Click += new System.EventHandler(this.changeColor);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator18,
            this.toolStripDropDownButton1,
            this.toolStripSeparator17,
            this.toolStripDropDownButton2});
            this.toolStrip2.Location = new System.Drawing.Point(76, 24);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(196, 25);
            this.toolStrip2.TabIndex = 6;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.level0,
            this.level1,
            this.level2,
            this.level3});
            this.toolStripDropDownButton1.Image = global::TapangGraphicsApp.Properties.Resources.penwidth;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(91, 22);
            this.toolStripDropDownButton1.Text = "Pen Width";
            // 
            // level0
            // 
            this.level0.CheckOnClick = true;
            this.level0.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level0.Image = global::TapangGraphicsApp.Properties.Resources.pen1;
            this.level0.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.level0.Name = "level0";
            this.level0.ShowShortcutKeys = false;
            this.level0.Size = new System.Drawing.Size(201, 52);
            this.level0.Text = "1 Pixel";
            this.level0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.level0.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.level0.Click += new System.EventHandler(this.penWidth);
            // 
            // level1
            // 
            this.level1.CheckOnClick = true;
            this.level1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level1.Image = global::TapangGraphicsApp.Properties.Resources.pen2;
            this.level1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.level1.Name = "level1";
            this.level1.Size = new System.Drawing.Size(201, 52);
            this.level1.Text = "2 Pixel";
            this.level1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.level1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.level1.Click += new System.EventHandler(this.penWidth);
            // 
            // level2
            // 
            this.level2.Checked = true;
            this.level2.CheckOnClick = true;
            this.level2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.level2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level2.Image = global::TapangGraphicsApp.Properties.Resources.pen3;
            this.level2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.level2.Name = "level2";
            this.level2.Size = new System.Drawing.Size(201, 52);
            this.level2.Text = "3 Pixel";
            this.level2.Click += new System.EventHandler(this.penWidth);
            // 
            // level3
            // 
            this.level3.CheckOnClick = true;
            this.level3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level3.Image = global::TapangGraphicsApp.Properties.Resources.pen4;
            this.level3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.level3.Name = "level3";
            this.level3.Size = new System.Drawing.Size(201, 52);
            this.level3.Text = "4 Pixel";
            this.level3.Click += new System.EventHandler(this.penWidth);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.solidLine,
            this.dashLine,
            this.dashDot,
            this.dashLineDot,
            this.dashLineDotDot});
            this.toolStripDropDownButton2.Image = global::TapangGraphicsApp.Properties.Resources.dashstyle;
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(90, 22);
            this.toolStripDropDownButton2.Text = "Dash Style";
            // 
            // solidLine
            // 
            this.solidLine.Checked = true;
            this.solidLine.CheckOnClick = true;
            this.solidLine.CheckState = System.Windows.Forms.CheckState.Checked;
            this.solidLine.Name = "solidLine";
            this.solidLine.Size = new System.Drawing.Size(169, 22);
            this.solidLine.Text = "Solid Line";
            this.solidLine.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // dashLine
            // 
            this.dashLine.CheckOnClick = true;
            this.dashLine.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dashLine.Name = "dashLine";
            this.dashLine.Size = new System.Drawing.Size(169, 22);
            this.dashLine.Text = "Dash Line";
            this.dashLine.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // dashDot
            // 
            this.dashDot.CheckOnClick = true;
            this.dashDot.Name = "dashDot";
            this.dashDot.Size = new System.Drawing.Size(169, 22);
            this.dashDot.Text = "Dash Dot";
            this.dashDot.Click += new System.EventHandler(this.dashDotToolStripMenuItem_Click);
            // 
            // dashLineDot
            // 
            this.dashLineDot.CheckOnClick = true;
            this.dashLineDot.Name = "dashLineDot";
            this.dashLineDot.Size = new System.Drawing.Size(169, 22);
            this.dashLineDot.Text = "Dash Line Dot";
            this.dashLineDot.Click += new System.EventHandler(this.dashLineDotToolStripMenuItem_Click);
            // 
            // dashLineDotDot
            // 
            this.dashLineDotDot.CheckOnClick = true;
            this.dashLineDotDot.Name = "dashLineDotDot";
            this.dashLineDotDot.Size = new System.Drawing.Size(169, 22);
            this.dashLineDotDot.Text = "Dash Line Dot Dot";
            this.dashLineDotDot.Click += new System.EventHandler(this.dashLineDotDotToolStripMenuItem_Click);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator19,
            this.drawLine,
            this.toolStripSeparator13,
            this.Drawpoly,
            this.toolStripSeparator7,
            this.drawRec,
            this.toolStripSeparator14,
            this.drawEllipse,
            this.toolStripSeparator21,
            this.eraser,
            this.toolStripSeparator15,
            this.insertText,
            this.toolStripSeparator6});
            this.toolStrip3.Location = new System.Drawing.Point(272, 24);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(183, 25);
            this.toolStrip3.TabIndex = 8;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(6, 25);
            // 
            // drawLine
            // 
            this.drawLine.CheckOnClick = true;
            this.drawLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.drawLine.Image = global::TapangGraphicsApp.Properties.Resources.lineline;
            this.drawLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.drawLine.Name = "drawLine";
            this.drawLine.Size = new System.Drawing.Size(23, 22);
            this.drawLine.Text = "toolStripButton1";
            this.drawLine.ToolTipText = "Draw Line";
            this.drawLine.Click += new System.EventHandler(this.drawLine_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // Drawpoly
            // 
            this.Drawpoly.CheckOnClick = true;
            this.Drawpoly.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Drawpoly.Image = global::TapangGraphicsApp.Properties.Resources.polylines2;
            this.Drawpoly.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Drawpoly.Name = "Drawpoly";
            this.Drawpoly.Size = new System.Drawing.Size(23, 22);
            this.Drawpoly.Text = "Polyline";
            this.Drawpoly.ToolTipText = "Draw Polyline";
            this.Drawpoly.Click += new System.EventHandler(this.Drawpoly_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // drawRec
            // 
            this.drawRec.CheckOnClick = true;
            this.drawRec.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.drawRec.Image = global::TapangGraphicsApp.Properties.Resources.recrec;
            this.drawRec.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.drawRec.Name = "drawRec";
            this.drawRec.Size = new System.Drawing.Size(23, 22);
            this.drawRec.Text = "toolStripButton1";
            this.drawRec.ToolTipText = "Draw Rectangle";
            this.drawRec.Click += new System.EventHandler(this.drawRec_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // drawEllipse
            // 
            this.drawEllipse.CheckOnClick = true;
            this.drawEllipse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.drawEllipse.Image = global::TapangGraphicsApp.Properties.Resources.ellipse;
            this.drawEllipse.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.drawEllipse.Name = "drawEllipse";
            this.drawEllipse.Size = new System.Drawing.Size(23, 22);
            this.drawEllipse.Text = "toolStripButton1";
            this.drawEllipse.ToolTipText = "Draw Ellipse";
            this.drawEllipse.Click += new System.EventHandler(this.drawEllipse_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(6, 25);
            // 
            // eraser
            // 
            this.eraser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.eraser.Image = global::TapangGraphicsApp.Properties.Resources.eraser;
            this.eraser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.eraser.Name = "eraser";
            this.eraser.Size = new System.Drawing.Size(23, 22);
            this.eraser.Text = "toolStripButton1";
            this.eraser.ToolTipText = "Eraser";
            this.eraser.Click += new System.EventHandler(this.eraser_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // insertText
            // 
            this.insertText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.insertText.Image = global::TapangGraphicsApp.Properties.Resources.letterA;
            this.insertText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.insertText.Name = "insertText";
            this.insertText.Size = new System.Drawing.Size(23, 22);
            this.insertText.Text = "toolStripButton2";
            this.insertText.ToolTipText = "Text tool";
            this.insertText.Click += new System.EventHandler(this.insertText_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // textFontStyle
            // 
            this.textFontStyle.FormattingEnabled = true;
            this.textFontStyle.Items.AddRange(new object[] {
            "Regular",
            "Italic",
            "Underline",
            "Bold"});
            this.textFontStyle.Location = new System.Drawing.Point(232, 1);
            this.textFontStyle.Name = "textFontStyle";
            this.textFontStyle.Size = new System.Drawing.Size(121, 21);
            this.textFontStyle.TabIndex = 11;
            this.textFontStyle.TabStop = false;
            this.textFontStyle.Text = "Regular";
            // 
            // textOptionPanel
            // 
            this.textOptionPanel.Controls.Add(this.textContainer);
            this.textOptionPanel.Controls.Add(this.textFontSize);
            this.textOptionPanel.Controls.Add(this.label4);
            this.textOptionPanel.Controls.Add(this.label3);
            this.textOptionPanel.Controls.Add(this.label2);
            this.textOptionPanel.Controls.Add(this.label1);
            this.textOptionPanel.Controls.Add(this.textFont);
            this.textOptionPanel.Controls.Add(this.textFontStyle);
            this.textOptionPanel.Location = new System.Drawing.Point(464, 24);
            this.textOptionPanel.Name = "textOptionPanel";
            this.textOptionPanel.Size = new System.Drawing.Size(737, 22);
            this.textOptionPanel.TabIndex = 12;
            this.textOptionPanel.Visible = false;
            // 
            // textContainer
            // 
            this.textContainer.Location = new System.Drawing.Point(535, 1);
            this.textContainer.Name = "textContainer";
            this.textContainer.Size = new System.Drawing.Size(192, 20);
            this.textContainer.TabIndex = 14;
            // 
            // textFontSize
            // 
            this.textFontSize.Location = new System.Drawing.Point(431, 2);
            this.textFontSize.Name = "textFontSize";
            this.textFontSize.Size = new System.Drawing.Size(41, 20);
            this.textFontSize.TabIndex = 13;
            this.textFontSize.TabStop = false;
            this.textFontSize.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(494, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Text";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(370, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Font Size";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Font Style";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Font";
            // 
            // textFont
            // 
            this.textFont.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFont.FormattingEnabled = true;
            this.textFont.Items.AddRange(new object[] {
            "Arial",
            "Calibri",
            "Impact",
            "Microsft  Sans Serif",
            "Tahoma",
            "Times New Roman"});
            this.textFont.Location = new System.Drawing.Point(44, 1);
            this.textFont.Name = "textFont";
            this.textFont.Size = new System.Drawing.Size(121, 21);
            this.textFont.TabIndex = 11;
            this.textFont.TabStop = false;
            this.textFont.Text = "Times New Roman";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::TapangGraphicsApp.Properties.Resources.griid;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1305, 233);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // statusStrip1
            // 
            this.statusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ssInstruction,
            this.ssCursorLoc,
            this.ssDate});
            this.statusStrip1.Location = new System.Drawing.Point(0, 235);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1305, 22);
            this.statusStrip1.TabIndex = 17;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ssInstruction
            // 
            this.ssInstruction.Name = "ssInstruction";
            this.ssInstruction.Size = new System.Drawing.Size(67, 17);
            this.ssInstruction.Text = "Instruction:";
            // 
            // ssCursorLoc
            // 
            this.ssCursorLoc.Name = "ssCursorLoc";
            this.ssCursorLoc.Size = new System.Drawing.Size(1189, 17);
            this.ssCursorLoc.Spring = true;
            this.ssCursorLoc.Text = "Cursor Location:";
            // 
            // ssDate
            // 
            this.ssDate.Name = "ssDate";
            this.ssDate.Size = new System.Drawing.Size(34, 17);
            this.ssDate.Text = "Date:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1305, 257);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.textOptionPanel);
            this.Controls.Add(this.toolStrip3);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.colorBox);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Simple Graphics Application (JDT)";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.colorBox.ResumeLayout(false);
            this.colorBox.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.textOptionPanel.ResumeLayout(false);
            this.textOptionPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textFontSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem penWidthbox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem resetCanvas;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem customizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStrip colorBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton ColorHolderBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem level1;
        private System.Windows.Forms.ToolStripMenuItem level2;
        private System.Windows.Forms.ToolStripMenuItem level3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem solidLine;
        private System.Windows.Forms.ToolStripMenuItem dashLine;
        private System.Windows.Forms.ToolStripMenuItem dashDot;
        private System.Windows.Forms.ToolStripMenuItem dashLineDot;
        private System.Windows.Forms.ToolStripMenuItem dashLineDotDot;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton drawLine;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripButton drawRec;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripButton drawEllipse;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripButton eraser;
        private System.Windows.Forms.ToolStripMenuItem gridLinesToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem brownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yellowtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greentoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bluetoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem whiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton insertText;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ComboBox textFontStyle;
        private System.Windows.Forms.Panel textOptionPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown textFontSize;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox textFont;
        private System.Windows.Forms.TextBox textContainer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripButton Drawpoly;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem level0;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel ssInstruction;
        private System.Windows.Forms.ToolStripStatusLabel ssCursorLoc;
        private System.Windows.Forms.ToolStripStatusLabel ssDate;
    }
}

